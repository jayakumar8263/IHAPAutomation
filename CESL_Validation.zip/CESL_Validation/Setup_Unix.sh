echo "Installing Pandas..."
sudo pip install pandas

echo "Installing envoy..."
sudo pip install envoy

echo "Installing plotly..."
sudo pip install plotly

echo "Installing xlsxwriter..."
sudo pip install xlsxwriter